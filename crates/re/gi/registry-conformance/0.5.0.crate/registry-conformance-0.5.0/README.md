# registry-conformance

This library contains behavioral tests for a [Cargo
registry][registry]. This is useful if you are creating your own
registry and want some level of assurance that it's compatible with
Cargo.

[registry]: https://doc.rust-lang.org/cargo/reference/registries.html
